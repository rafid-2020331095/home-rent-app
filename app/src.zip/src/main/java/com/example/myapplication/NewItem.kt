package com.example.myapplication

data class NewItem(val bedroom:String,val bathroom:String,val dyning:String,val drawing:String,val rentper:String,val rentad:String,
                   val emailowner:String,val contact:String,val addressa:String,val descriptiona:String){
    constructor():this("","","","","","","","","","")

}
