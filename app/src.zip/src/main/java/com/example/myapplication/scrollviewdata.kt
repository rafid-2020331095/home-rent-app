package com.example.myapplication

import android.os.Parcel
import android.os.Parcelable
import java.net.PasswordAuthentication

data class scrollviewdata (
    var rentper: String? = null, var addressa:String? = null, var contact:String? = null,var bedroom:String?=null,var bathroom:String?=null,var dyning:String?=null,var drawing:String?=null,
 var rentad:String?=null,var emailowner:String?=null,var descriptiona:String?=null

    )

//data class scrollviewdata {
//    var rentper: String? = null, var addressa:String? = null
//}


