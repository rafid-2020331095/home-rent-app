package com.example.myapplication

data class userdata(
    val username:String?=null,
    val password:String?=null,


)
